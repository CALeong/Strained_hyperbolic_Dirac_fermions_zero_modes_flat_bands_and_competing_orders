import numpy as np
from Fundamental.General_Hamiltonian_Strain import general_q3_hamiltonian_with_strain
from KPM.KPM import moments_ADOS_general
from KPM.measure import rescale_operator_unity_window
from KPM.parallel_compute import random_vectors_arr_generate
import pickle
from joblib import Parallel, delayed
from scipy.sparse.linalg import eigsh


if __name__ == '__main__':

    pval = 14
    nval = 7
    eigval_min = -5
    eigval_max = 5
    number_moments = 16384
    num_rand_vecs = 12
    qax_list = np.round(np.linspace(0.01, 0.02, 11), 3)

    save_dir = '/home/cal422/PycharmProjects/KPMPackage/Axial_Magnetic_Field_Calculations/p14q3n7/Results'

    def run_routine(pval, nval, qax, eigval_min, eigval_max, number_moments, num_rand_vecs):
        print('Computing qax={} result...'.format(qax))
        ham = general_q3_hamiltonian_with_strain(pval, nval, qax)
        ham = rescale_operator_unity_window(ham.tocsr(), eigval_min, eigval_max)
        results = moments_ADOS_general(ham, number_moments,
                                       random_vectors_arr_generate(num_rand_vecs, ham.shape[0]))
        np.save(save_dir + '/' + 'p{}q3n{}_qax{}_{}moments'.format(pval, nval, qax, number_moments), results)
        print('Finished computing qax={} result...'.format(qax))

    Parallel(n_jobs=len(qax_list))(
        delayed(run_routine)
        (pval, nval, qaxval, eigval_min, eigval_max, number_moments, num_rand_vecs)
        for qaxval in qax_list
    )

    metadata_dict = {
        'Number random vectors': num_rand_vecs,
        'Number moments up to': number_moments,
        'Eigenvalue extrema': (eigval_min, eigval_max)
    }

    sf = open(save_dir + '/' + 'metadata.pkl', 'wb')
    pickle.dump(metadata_dict, sf)
    sf.close()

