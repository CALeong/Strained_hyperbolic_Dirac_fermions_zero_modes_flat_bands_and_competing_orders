import numpy as np
import pickle

savedir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/Mathematica_Final_Plots/Final_Data/Axial_Magnetic_Catalysis_Haldane_LowerToleranceData/p10q3n4a0d4_tolerance0d002'
datadir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/Hyperbolic_NoAxial_LowerTolerance'

datafile = open(datadir + '/p10q3n4a0.4_HaldaneNH_resultsdict_smallertolerance0.002.pkl', 'rb')
resdict = pickle.load(datafile)
datafile.close()

v2vals = np.array([])
t2vals = np.array([])
for k in resdict.keys():
    v2vals = np.append(v2vals, float(k.split('=')[1]))
    t2vals = np.append(t2vals, np.average(np.abs(np.imag(resdict[k][2, :]))))

np.savetxt(savedir + '/p10q3n4a0.4_axialfield0_smallertolerance0.002_HaldaneResults.txt',
           np.vstack((np.sort(v2vals), t2vals[np.argsort(v2vals)])))
