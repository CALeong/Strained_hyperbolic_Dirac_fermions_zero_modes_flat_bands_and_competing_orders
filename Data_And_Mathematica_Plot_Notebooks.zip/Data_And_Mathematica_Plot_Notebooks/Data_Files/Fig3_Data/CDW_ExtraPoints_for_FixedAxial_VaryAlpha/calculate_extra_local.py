import numpy as np
from Axial_Magnetic_Field.NonHermitian import N_from_center_tight_bind_ham_nonhermitian_honeycomb
from Self_Consistent_Hartree_Fock.Self_Consistent_Hartree_Fock import selfconsist_hartreefock_NonHermitian_Honeycomb_PBC_DisorderAlreadyAdded_SaveRawOutputs


###
savedir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/Mathematica_Final_Plots/Final_Data/Axial_Magnetic_Catalysis_CDW_ExtraPoints_for_FixedAxial_VaryAlpha/raw_npy_files_local'
hamdir = savedir
num_levels = 20
alpha = 0.8
axialfield_list = [0.09]
vval_list = [0.32, 0.36]
###

for axialfield in axialfield_list:
    disorderconfig = np.load(hamdir + '/honeycombOBC_nl20a{}_axialfield{}_disorderconfig.npy'.format(alpha, axialfield))
    axialham = N_from_center_tight_bind_ham_nonhermitian_honeycomb(num_levels, alpha, axialfield) + np.diag(disorderconfig)
    raw, sysdata, centdata = selfconsist_hartreefock_NonHermitian_Honeycomb_PBC_DisorderAlreadyAdded_SaveRawOutputs(num_levels, axialham, 0.1, 0.001, vval_list)
    np.save(savedir + '/honeycombOBC_nl{}a{}_axialfield{}_rawdata'.format(num_levels, alpha, axialfield), raw)
    np.save(savedir + '/honeycombOBC_nl{}a{}_axialfield{}_systemdata'.format(num_levels, alpha, axialfield), sysdata)
    np.save(savedir + '/honeycombOBC_nl{}a{}_axialfield{}_centerdata'.format(num_levels, alpha, axialfield), centdata)
