import numpy as np
import os

# datadir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/Mathematica_Final_Plots/Final_Data/Axial_Magnetic_Catalysis_CDW_ExtraPoints_for_FixedAxial_VaryAlpha/raw_npy_files_from_cluster'
# savedir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/Mathematica_Final_Plots/Final_Data/Axial_Magnetic_Catalysis_CDW_ExtraPoints_for_FixedAxial_VaryAlpha'
#
# datafiles = os.listdir(datadir)
#
# for df in datafiles:
#     if 'systemdata.npy' in df:
#         data = np.load(datadir + '/' + df)
#         np.savetxt(savedir + '/' + df.split('.npy')[0] + '.txt', data)

savedir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/Mathematica_Final_Plots/Final_Data/Axial_Magnetic_Catalysis_CDW_ExtraPoints_for_FixedAxial_VaryAlpha/raw_npy_files_local'
datafile = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/Mathematica_Final_Plots/Final_Data/Axial_Magnetic_Catalysis_CDW_ExtraPoints_for_FixedAxial_VaryAlpha/raw_npy_files_local/honeycombOBC_nl20a0.8_axialfield0.09_systemdata.npy'
data = np.load(datafile)
np.savetxt(savedir + '/honeycombOBC_nl20a0.8_axialfield0.09_systemdata.txt', data)

