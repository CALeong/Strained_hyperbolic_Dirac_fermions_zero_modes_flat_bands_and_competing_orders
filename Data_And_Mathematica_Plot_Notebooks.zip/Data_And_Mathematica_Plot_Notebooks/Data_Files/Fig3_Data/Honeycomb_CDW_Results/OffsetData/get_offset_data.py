import numpy as np

savedir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/Mathematica_Final_Plots/Final_Data/Honeycomb_Computations/CDW_Results/OffsetData'
datadir = '/home/cal422/../../mnt/archives2/Chris/Hyperbolic_Lattice_Self_Consistent_Hartree_Fock_Data_Acquisition_Data/SCHF_NonHermitian_Honeycomb_Jobs_OpenBC/nl20_Honeycomb_OpenBC_FromCluster_12_08_2023/amag_0/Combined_Data'

alpha_list = [0, 0.4, 0.8]
for alpha in alpha_list:
    sysdata = np.load(datadir + '/System_a{}.npy'.format(alpha))
    rawdata = np.load(datadir + '/Raw_a{}.npy'.format(alpha))
    vvals = np.real(rawdata[:, 0])
    np.savetxt(savedir + '/honeycombOBC_nl20a{}_NoAxialField_OffsetData.txt'.format(alpha),
               np.vstack((vvals, sysdata)))


