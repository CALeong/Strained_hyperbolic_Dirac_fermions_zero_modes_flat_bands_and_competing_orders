import numpy as np
import os

savedir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/Mathematica_Final_Plots/Final_Data/Honeycomb_Computations/CDW_Results'
datadir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/Honeycomb_Computations/CDW_Results_EVENMORE'

datafiles = os.listdir(datadir)
for df in datafiles:
    if '_systemdata.npy' in df:
        data = np.load(datadir + '/' + df)
        np.savetxt(savedir + '/' + df.split('.npy')[0] + '_EVENMORE.txt', data)
