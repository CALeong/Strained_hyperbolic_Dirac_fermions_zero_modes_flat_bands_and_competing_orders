import numpy as np
from Axial_Magnetic_Field.Order_Parameter import total_magnetization_calculate, total_cdw_calculate

###
savedir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/Mathematica_Final_Plots/Final_Data/p14q3n3_AxialField_Spinless'

rawdatadir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/p14q3n3_Spinless_Results_from_Cluster'
noaxialrawdatadir = '/mnt/archives2/Chris/Hyperbolic_Lattice_Self_Consistent_Hartree_Fock_Data_Acquisition_Data/SCHF_NonHermitian_Jobs/p14q3n3/Combined_Data'

p = 14
q = 3
n = 3
###

asfieldlist = [0.1, 0.12, 0.14, 0.16, 0.18]
alist = [0, 0.4, 0.8]
for alpha in alist:
    for asfield in asfieldlist:
        rawdata = np.load(rawdatadir + '/p{}q{}n{}a{}_axialfield{}_rawdata.npy'.format(p, q, n, alpha, asfield))
        noaxial_rawdata_all = np.load(noaxialrawdatadir + '/Raw_a{}.npy'.format(alpha))
        # print(np.max(np.abs(np.imag(rawdata))), np.max(np.abs(np.imag(noaxial_rawdata_all))))
        noaxial_rawdata_rel = np.zeros(np.shape(rawdata))
        for ui in range(len(rawdata[:, 0])):
            noaxial_rawdata_rel[ui, :] = noaxial_rawdata_all[np.where((np.around(rawdata[:,0],5))[ui] == np.around(noaxial_rawdata_all[:,0],5))[0], :]

        uvals_afm, afm_order = total_cdw_calculate(rawdata)
        uvals_afm_offset, afm_order_offset = total_cdw_calculate(noaxial_rawdata_rel)
        # print(np.unique(np.sort(uvals_afm) - np.sort(uvals_afm_offset)))
        afm_order_final = afm_order[np.argsort(uvals_afm)] - afm_order_offset[np.argsort(uvals_afm_offset)]
        uvals_afm_final = np.sort(uvals_afm)

        # uvals_mag, mag_order = total_magnetization_calculate(rawdata)
        # uvals_mag_offset, mag_order_offset = total_magnetization_calculate(noaxial_rawdata_rel)
        # print(np.unique(np.sort(uvals_mag) - np.sort(uvals_mag_offset)))
        # mag_order_final = mag_order[np.argsort(uvals_mag)] - mag_order_offset[np.argsort(uvals_mag_offset)]
        # uvals_mag_final = np.sort(uvals_mag)

        # np.savetxt(savedir + '/p{}q{}n{}a{}_axialfield{}_cdwvvalues.txt'.format(p, q, n, alpha, asfield), uvals_afm_final)
        # np.savetxt(savedir + '/p{}q{}n{}a{}_axialfield{}_cdworderparams.txt'.format(p, q, n, alpha, asfield), afm_order_final)
        np.savetxt(savedir + '/p{}q{}n{}a{}_axialfield{}_CDWResultsMat.txt'.format(p, q, n, alpha, asfield),
                   np.vstack((uvals_afm_final, afm_order_final)))

        # np.savetxt(savedir + '/p{}q{}n{}a{}_axialfield{}_magvvalues.txt'.format(p, q, n, alpha, asfield), uvals_mag_final)
        # np.savetxt(savedir + '/p{}q{}n{}a{}_axialfield{}_magorderparams.txt'.format(p, q, n, alpha, asfield), mag_order_final)

