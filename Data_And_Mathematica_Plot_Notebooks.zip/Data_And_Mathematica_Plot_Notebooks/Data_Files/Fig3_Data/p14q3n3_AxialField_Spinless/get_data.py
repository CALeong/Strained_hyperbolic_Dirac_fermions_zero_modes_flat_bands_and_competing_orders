import numpy as np
import os
from Axial_Magnetic_Field.Order_Parameter import total_cdw_calculate

datadir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/p14q3n3_Spinless_Results_from_Cluster'
savedir = '/home/cal422/PycharmProjects/Hyperbolic_Dirac_Systems_Axial_Magnetic_Field/Mathematica_Final_Plots/Final_Data/p14q3n3_AxialField_Spinless'

datafiles = os.listdir(datadir)
for df in datafiles:
    rawdata = np.load(datadir + '/' + df)
    intvals, deltas = total_cdw_calculate(rawdata)
    np.savetxt(savedir + '/' + df.split('_rawdata.npy')[0] + '_OrderAsFunctionOfInteractions.txt', np.vstack((intvals, deltas)))
    